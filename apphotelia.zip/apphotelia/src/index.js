import express from "express";
import routesuser from "/routes/user.routes.js"
import routesuser from "/routes/index.routes.js"
const app=express()

app.use(routesuser)
app.use(routeindex)


app.listen(3304)
console.log("ejecutandose en el puerto 3304")