import { Router } from "express";
import routesusers from "./routes/user.routes.js"

const rout=Router()

app.use(routesusers)

rout.get('/users', (req,res)=> res.send("obteniendo datos de los usuarios"))
rout.post('/users', (req,res)=> res.send("creando un usuario"))
rout.put('/users', (req,res)=> res.send("actualizando un usuario"))
rout.delete('/users', (req,res)=> res.send("eliminando un usuario"))

export default rout