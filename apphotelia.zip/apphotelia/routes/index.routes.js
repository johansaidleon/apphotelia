import { Router } from "express";

const rout=Router()

import { Pool } from "../db.js"


rout.get('/ping',async(req,res)=>{
    const result=await pool.query('SELECT 1+1 AS resp')
    res.json(result)
})

export default Report
