create database hoteliadb;
use hoteliadb;
create table usuario(
    idusuario int auto_increment not null,
    nombres varchar (50) not null,
    apellidos varchar (50) not null,
    email varchar (80) not null ,
    password varchar(20) not null,
    tipousuario varchar(15) not null,
    estadousuario boolean(1)
)

