import express from "express";
const app=express()

app.get('/users', (req,res)=> res.send("obteniendo datos de los usuarios"))
app.post('/users', (req,res)=> res.send("creando un usuario"))
app.put('/users', (req,res)=> res.send("actualizando un usuario"))
app.delete('/users', (req,res)=> res.send("eliminando un usuario"))


app.listen(3304)
console.log("ejecutandose en el puerto 3304")